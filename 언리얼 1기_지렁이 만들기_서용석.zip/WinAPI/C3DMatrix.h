#include "Stdafx.h"

#pragma once
class C3DMatrix
{
};


#include "Stdafx.h"
#include "IWindowMessageHandler.h"
